package com.egglayer.android.mcuquiz;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declared Variables
    int scores = 0, scores2 = 0, scores3 = 0, scores4 = 0, scores5 = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );

        setContentView( R.layout.activity_main );
    }

    public void RadioBtnClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {

            //qst 1

            case R.id.radioBtn1a:
                if (checked)
                    scores = 0;
                break;

            case R.id.radioBtn1b:
                if (checked)
                    scores = 0;
                break;

            case R.id.radioBtn1c:
                if (checked)
                    scores = 0;
                break;

            case R.id.radioBtn1d:
                if (checked)
                    scores += 1;
                break;

            //qst 2

            case R.id.radioBtn2a:
                if (checked)
                    scores2 = 0;
                break;

            case R.id.radioBtn2b:
                if (checked)
                    scores2 += 1;
                break;

            case R.id.radioBtn2c:
                if (checked)
                    scores2 = 0;
                break;

            case R.id.radioBtn2d:
                if (checked)
                    scores2 = 0;
                break;

            //qst 3
            case R.id.radioBtn3a:
                if (checked)
                    scores3 = 0;
                break;

            case R.id.radioBtn3b:
                if (checked)
                    scores3 = 0;
                break;

            case R.idradioBtn3c:
                if (checked)
                    scores3 += 1;
                break;

            case R.id.radioBtnd:
                if (checked)
                    scores3 = 0;
                break;


            //qst 4
            case R.id.radioBtn4a:
                if (checked)
                    scores4 += 0;
                break;

            case R.id.radioBtn4b:
                if (checked)
                    scores4 = 0;
                break;

            case R.idradioBtn4c:
                if (checked)
                    scores4 += 1;
                break;

            case R.id.radioBtn4d:
                if (checked)
                    scores4 = 0;
                break;

            //ends here
        }
    }

    private void question1code() {
        RadioButton button1 = findViewById( R.id.radioBtn1c );
        RadioButton button2 = findViewById( R.id.radioBtn1a );
        RadioButton button3 = findViewById( R.id.radioBtn1b );
        RadioButton button4 = findViewById( R.id.radioBtn1d );

        if (button2.isChecked()) {
            button2.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_one = findViewById( R.id.answer_one );
            answer_one.setText( getResources().getString( R.string.answer_one ) );
            answer_one.setVisibility( View.VISIBLE );
            answer_one.setBackground( getResources().getDrawable( R.drawable.hdt ) );

        } else if (button3.isChecked()) {
            button3.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_one = findViewById( R.id.answer_one );
            answer_one.setText( getResources().getString( R.string.answer_one ) );
            answer_one.setVisibility( View.VISIBLE );
            answer_one.setBackground( getResources().getDrawable( R.drawable.hdt ) );

        } else if (button4.isChecked()) {
            button4.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_one = findViewById( R.id.answer_one );
            answer_one.setText( getResources().getString( R.string.answer_one ) );
            answer_one.setVisibility( View.VISIBLE );
            answer_one.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        button1.setEnabled( false );
        button2.setEnabled( false );
        button3.setEnabled( false );
        button4.setEnabled( false );
    }

    private void question2code() {
        RadioButton button1 = findViewById( R.id.radioBtn2a );
        RadioButton button2 = findViewById( R.id.radioBtn2b );
        RadioButton button3 = findViewById( R.id.radioBtn2c );
        RadioButton button4 = findViewById( R.id.radioBtn2d );

        if (button2.isChecked()) {
            button2.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_two = findViewById( R.id.answer2 );
            answer_two.setText( getResources().getString( R.string.answer_two ) );
            answer_two.setVisibility( View.VISIBLE );
            answer_two.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button3.isChecked()) {
            button3.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_two = findViewById( R.id.answer2 );
            answer_two.setText( getResources().getString( R.string.answer_two ) );
            answer_two.setVisibility( View.VISIBLE );
            answer_two.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button4.isChecked()) {
            button4.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_two = findViewById( R.id.answer2 );
            answer_two.setText( getResources().getString( R.string.answer_two ) );
            answer_two.setVisibility( View.VISIBLE );
            answer_two.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        button1.setEnabled( false );
        button2.setEnabled( false );
        button3.setEnabled( false );
        button4.setEnabled( false );
    }

    private void question3code() {
        RadioButton button1 = findViewById( R.id.radioBtn3b );
        RadioButton button2 = findViewById( R.id.radioBtn3a );
        RadioButton button3 = findViewById( R.id.radioBtn3c );
        RadioButton button4 = findViewById( R.id.radioBtn3d );

        if (button2.isChecked()) {
            button2.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_three = findViewById( R.id.answer3 );
            answer_three.setText( getResources().getString( R.string.answer_three ) );
            answer_three.setVisibility( View.VISIBLE );
            answer_three.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button3.isChecked()) {
            button3.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_three = findViewById( R.id.answer3 );
            answer_three.setText( getResources().getString( R.string.answer_three ) );
            answer_three.setVisibility( View.VISIBLE );
            answer_three.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button4.isChecked()) {
            button4.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_three = findViewById( R.id.answer3 );
            answer_three.setText( getResources().getString( R.string.answer_three ) );
            answer_three.setVisibility( View.VISIBLE );
            answer_three.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        button1.setEnabled( false );
        button2.setEnabled( false );
        button3.setEnabled( false );
        button4.setEnabled( false );
    }

    private void question4code() {
        RadioButton button1 = findViewById( R.id.radioBtn4b )
        RadioButton button2 = findViewById( R.id.radioBtn4a );
        RadioButton button3 = findViewById( R.id.radioBtn4c );
        RadioButton button4 = findViewById( R.id.radioBtn4d );

        if (button2.isChecked()) {
            button2.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_four = findViewById( R.id.answer_four );
            answer_four.setText( getResources().getString( R.string.answer_four ) );
            answer_four.setVisibility( View.VISIBLE );
            answer_four.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button3.isChecked()) {
            button3.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_four = findViewById( R.id.answer_four );
            answer_four.setText( getResources().getString( R.string.answer_four ) );
            answer_four.setVisibility( View.VISIBLE );
            answer_four.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        if (button4.isChecked()) {
            button4.setBackground( getResources().getDrawable( R.drawable.radio_btn ) );
            TextView answer_four = findViewById( R.id.answer_four );
            answer_four.setText( getResources().getString( R.string.answer_four ) );
            answer_four.setVisibility( View.VISIBLE );
            answer_four.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        button1.setEnabled( false );
        button2.setEnabled( false );
        button3.setEnabled( false );
        button4.setEnabled( false );
    }

    private void qstFour() {
        TextInputEditText ed = findViewById( R.id.ee );
        String myAnswer = ed.getText().toString();
        String mcu = "Marvel Cinematic Universe";

        if (myAnswer.trim().equalsIgnoreCase( mcu )) {
            scores5 = +1;
        } else {
            TextView answer_five = findViewById( R.id.answer_five );
            answer_five.setText( getResources().getString( R.string.answer_five ) );
            answer_five.setVisibility( View.VISIBLE );
            answer_five.setBackground( getResources().getDrawable( R.drawable.hdt ) );
        }
        ed.setEnabled( false );
    }
    public void submitButton(View view){
        //errors
        RadioGroup rg1 = findViewById(R.id.rg1);
        RadioGroup rg2 = findViewById(R.id.rg2);
        RadioGroup rg3 = findViewById(R.id.rg3);
        RadioGroup rg4 = findViewById(R.id.rg4);

        TextInputEditText ed = findViewById(R.id.editText);

        CheckBox CB1 = findViewById(R.id.checkbox_5b);//right answer
        CheckBox CB2 = findViewById(R.id.checkbox_5d);//right answer
        CheckBox CB3 = findViewById(R.id.checkbox_5a);
        CheckBox CB4 = findViewById(R.id.checkbox_5c);
        boolean checked = CB1.isChecked() || CB2.isChecked() || CB3.isChecked() || CB4.isChecked(); //at least one checkbox is checked

        if(rg1.getCheckedRadioButtonId() == -1){
            //if no RadioButton is checked
            Toast.makeText(this, "Question 1 not answered", Toast.LENGTH_SHORT).show();

        }else if(rg2.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Question 2 not answered", Toast.LENGTH_SHORT).show();

        }else if(rg3.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Question 3 not answered", Toast.LENGTH_SHORT).show();

        }else if (rg4.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Question 4 not answered", Toast.LENGTH_SHORT).show();

        }else if (!checked){
            Toast.makeText(this, "Question 5 not answered", Toast.LENGTH_SHORT).show();

        } else if (ed.length() == 0){
            Toast.makeText(this, "Question 6 not answered", Toast.LENGTH_SHORT).show();
        }
        else {
            //if at least one RadioButton & checkbox is checked and the editText not empty
            question1code();
            question2code();
            question3code();
            question4code();

            int totalScore = scores + scores2 + scores3 + scores4 + scores5;
            //Toasts
            if (totalScore <= 2){
                Toast.makeText(this, "Please try again", Toast.LENGTH_SHORT).show();
            }else if (totalScore == 3){
                Toast.makeText(this, "Nice one!", Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this, "Great!", Toast.LENGTH_SHORT).show();
            }

            //TextView
            TextView results = findViewById(R.id.results);
            results.setText(getResources().getString(R.string.results, totalScore));
            results.setVisibility(View.VISIBLE);

            //Buttons
            Button next = findViewById(R.id.next_btn);
            next.setVisibility(View.VISIBLE);
            Button submit = findViewById(R.id.submit_btn);
            submit.setEnabled(false);
        }
    }

    public void nextPage(View view){
        startActivity(new Intent(this, SecondActivity.class));
    }

    
}
